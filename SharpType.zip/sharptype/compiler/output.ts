
console.log("Hello");
console.log("World");
// bruh