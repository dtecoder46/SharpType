using System;

class Program {
  public static void Main (string[] args) {
    Console.Write("Hello");
    Console.Write("World");
    //&bruh
  }
}